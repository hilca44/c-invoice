programm for writing invoices
---
- json storage for  
    + address
    + order
    + expense
- output: pdf and txt
- search function
- document types:
    + estimation of costs
    + order confirmation
    + delivery note
    + invoices


installation linux (debian based)
---
$ sudo apt install nodejs npm
$ npm install


start c-invoice
---
jump into c-invoice and type:
$ node inv12.js
