#!/bin/sh
sudo apt install nodejs npm
#sudo pacman -S openscad nodejs npm
npm i cookie-parser express express-session morgan pbkdf2-password pdfkit pug session-file-store && read done
